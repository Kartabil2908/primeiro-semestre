// Crie um programa que escreva de 1 até 10 em um arquivo, armazenando um número
// por linha. //

#include <stdio.h>

int main(void) {

  FILE *arquivo;
  int c;

  arquivo = fopen("arquivo1.txt", "w");

  for (int i = 0; i <= 10; i++) {
    fprintf(arquivo, "%d \n", i);
  }

  fclose(arquivo);

  return 0;
}