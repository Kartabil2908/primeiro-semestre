
/* Faça um algoritmo que encontre as raízes de uma equação do segundo grau 𝑎𝑥2 + 𝑏𝑥 + 𝑐. O algoritmo deve ler os coeficientes 𝑎, 𝑏 e 𝑐 e determinar as raízes da equação. */

#include <stdio.h>
#include <math.h>

int main(void) {

  float x1, x2, a, b, c, delta;

printf("Digite o Valor de A \n");
  scanf("%f", &a);

  printf("Digite o Valor de B \n");
  scanf("%f", &b);

  printf("Digite o Valor de C \n");
  scanf("%f", &c);

  delta = pow(b,2) - 4*a*c;

  x1 = (-b + sqrt(delta))/2*a;

  x2 = (-b - sqrt(delta))/2*a;
  

printf("As raízes da equação são: %.2f e %.2f", x1, x2);



  
  return 0;
}