/* Faça um algoritmo que receba uma quantidade qualquer em minutos e converta em horas. */


#include <stdio.h>

int main(void) {

float hora, minuto;



    puts("Digite uma quantidade de minutos:");
    scanf("%f", &minuto);

  
  hora = minuto/60;
  
  printf("A quantidade em horas será de: %.2f", hora); 
  
  return 0;
}