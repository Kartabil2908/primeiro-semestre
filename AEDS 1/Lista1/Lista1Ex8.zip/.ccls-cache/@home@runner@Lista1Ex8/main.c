//Faça um algoritmo para calcular a área de um trapézio. O algoritmo deve ler o valor da base menor, da base maior e da altura. Em seguida, imprima o valor da área do trapézio//


#include <stdio.h>

int main(void) {

float base1, base2, altura, area;

  printf("Digite o valor da base menor: \n");
  scanf("%f", &base1);

  printf("Digite o valor da base maior: \n");
  scanf("%f", &base2);

  printf("Digite o valor da altura: \n");
  scanf("%f", &altura);

  area = (base1 + base2)*altura/2;
  
printf("O valor da área do trapézio é: %f", area);



  
  return 0;
}