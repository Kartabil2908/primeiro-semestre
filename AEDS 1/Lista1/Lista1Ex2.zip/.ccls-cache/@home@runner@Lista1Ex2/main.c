//Crie um algoritmo que calcule a média aritmética de 3 números fornecidos pelo usuário.//

#include <stdio.h>

int main(void) {

float n1, n2, n3, media;

 printf("Qual é o valor do primeiro número?");
  scanf("%f", &n1);

printf("Qual é o valor do primeiro número?");
  scanf("%f", &n2);

  printf("Qual é o valor do primeiro número?");
  scanf("%f", &n3);

  media = (n1+n2+n3)/3;

    printf("A média desses três números é %.2f", media);



  return 0;
}