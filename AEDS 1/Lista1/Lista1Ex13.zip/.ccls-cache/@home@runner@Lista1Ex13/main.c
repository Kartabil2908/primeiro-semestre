/*   Um funcionário recebe um salário fixo mais 4% de comissão sobre as vendas. Faça um algoritmo que receba o salário fixo do funcionário e o valor de suas vendas no mês, calcule e mostre a comissão e seu salário final   */

#include <stdio.h>

int main(void) {

  float salario, venda, comissao;

  printf("Digite o salário fixo do funcionário: \n");
  scanf("%f", &salario);

  printf("Digite o valor total das vendas feitas pelo funcionário: \n");
  scanf("%f", &venda);

  comissao = venda*1.4;

  salario = salario + comissao;

  printf("O salário final será de %.2f e o valor da comissão foi de %.2f reais",salario , comissao);

  



  
  return 0;
}