
// Faça um algoritmo que leia os lados de um retângulo e calcule sua área e seu perímetro //


#include <stdio.h>

int main(void) {

int comp, larg, area, peri;

  printf("Informe a medida de dois lados do retângulo: \n");
  scanf("%i %i", &comp , &larg);

  printf("Os dois lados do retângulo são: %i e %i \n", comp, larg);

  peri = comp*2 + larg*2;

  area = comp*larg;

  printf("O perímetro do retângulo é %i e a área é %i" , peri , area);

  
  return 0;
}