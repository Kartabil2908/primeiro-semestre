/*   Se o valor de A é 4, o valor de B é 5 e o valor de C é 1, avaliar as seguintes expressões, considerando ^ como uma
operação de potenciação, e % como o resto da divisão inteira:
(a) B * A – B ^ 2 / 4 * C
(b) (A * B) / 3 ^ 2
(c) (((B + C) / 2 * A + 10) * 3 * B) – 6
(d) 7 * 10 – 50 % 3 * 4 + 9
(e) (7 * (10 – 5) % 3) * 4 + 9     */