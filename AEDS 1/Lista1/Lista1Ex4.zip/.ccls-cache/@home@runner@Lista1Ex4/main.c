//Crie um algoritmo que calcule a média ponderada de 4 números passados pelo usuário, sabendo-se que os pesos são, respectivamente, 1, 2, 3 e 4.// 

#include <stdio.h>


int main(void) {

float n1, n2, n3, n4, media;

  printf("qual é o valor do primeiro número?");
  scanf("%f",&n1);

   printf("qual é o valor do segundo número?");
  scanf("%f",&n2);

   printf("qual é o valor do terceiro número?");
  scanf("%f",&n3);

   printf("qual é o valor do quarto número?");
  scanf("%f",&n4);

media = (n1*1 + n2*2 + n3*3 +n4*4)/10;

printf("O valor da média poderada é %.2f", media);




  return 0;
}