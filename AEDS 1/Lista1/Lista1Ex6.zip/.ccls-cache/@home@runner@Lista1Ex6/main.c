
//Faça um algoritmo que receba 2 números inteiros x e y e calcule o resto da divisão x/y //

#include <stdio.h>

int main(void) {

int x , y, divisao;

printf("Qual é o valor de x? \n ");
scanf("%i", &x);

printf("Qual é o valor de y? \n ");
scanf("%i", &y);

divisao = x%y;
  
  printf("Os dois números são: %i , %i \n", x, y);

  printf("O resto da divisão entre o X e o Y é: %i" , divisao);




  
  return 0;
}