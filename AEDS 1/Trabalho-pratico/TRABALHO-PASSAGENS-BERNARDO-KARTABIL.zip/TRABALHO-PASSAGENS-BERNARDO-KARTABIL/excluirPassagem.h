#ifndef EXCLUIRPASSAGEM_H
#define EXCLUIRPASSAGEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void excluirPassagem(){

FILE *arquivo, *novoArquivo;
char linha[80];
int IdUser, IdLinha, qtd, lastId, cont = 0;

printf("Digite o id da passagem: ");
scanf("%d", &IdUser);

arquivo = fopen("Passagens.txt", "r");
novoArquivo = fopen("Temporario.txt", "w");

fscanf(arquivo,"%d", &qtd);

qtd--;

fprintf(novoArquivo,"%d\n", qtd);
fscanf(arquivo,"%d", &lastId);

fprintf(novoArquivo,"%d\n", lastId);



while(fscanf(arquivo, " %[^\n]", linha) != EOF){
    sscanf(linha ,"%d", &IdLinha);

    if(IdLinha != IdUser ){
        fprintf(novoArquivo, "%s\n", linha);
    }

    cont++;
}

fclose(arquivo);
fclose(novoArquivo);

arquivo = fopen("Passagens.txt", "w");
novoArquivo = fopen("Temporario.txt", "r");


while(fscanf(novoArquivo, " %[^\n]", linha) != EOF){
    fprintf(arquivo,"%s\n", linha);


}

fclose(arquivo);
fclose(novoArquivo);
}


#endif
