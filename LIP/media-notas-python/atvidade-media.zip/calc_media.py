def calcularMedia(aluno):
    notas = [valor for chave, valor in aluno.items() if chave.startswith('Nota')]
    media = sum(notas) / len(notas)
    return round(media, 2)
