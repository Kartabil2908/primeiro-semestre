# Recado para o professor: Eu tive bastante dificuldade nessa segunda parte, mas eu
# consegui usando o chatGPT, ou seja, tem algumas coisas que eu ainda não entendo
# espero que compreenda. 

from calc_media import calcularMedia

limite_aprovacao = 60

dict_aluno1 = {
    'Nome': 'Ana',
    'Nota1': 99,
    'Nota2': 99,
    'Nota3': 99,
    'Nota4': 95,
}

dict_aluno2 = {
    'Nome': 'José',
    'Nota1': 7,
    'Nota2': 10,
    'Nota3': 12,
    'Nota4': 15,
}

dict_aluno3 = {
    'Nome': 'Bernardo',
    'Nota1': 7,
    'Nota2': 10,
    'Nota3': 12,
    'Nota4': 8,
}

dict_aluno4 = {
    'Nome': 'Carlos',
    'Nota1': 8,
    'Nota2': 9,
    'Nota3': 7,
    'Nota4': 10,
}

dict_aluno5 = {
    'Nome': 'Mariana',
    'Nota1': 10,
    'Nota2': 8,
    'Nota3': 7,
    'Nota4': 9,
}
alunos = [dict_aluno1, dict_aluno2, dict_aluno3]

for aluno in alunos: # Adicionando a nova chave 'Media' e 'Status' a cada dicionário
    aluno['Media'] = calcularMedia(aluno)
    aluno['Status'] = 'Aprovado' if aluno['Media'] >= limite_aprovacao else 'Reprovado'
for i, aluno in enumerate(alunos, 1): # Imprimindo os dicionários atualizados
    print(f'Aluno {i}: {aluno}')

alunos.extend([dict_aluno4, dict_aluno5]) # Adicionando mais dois estudantes

for aluno in alunos[3:]: # Recalculando a média e o status para os novos estudantes
    aluno['Media'] = calcularMedia(aluno)
    aluno['Status'] = 'Aprovado' if aluno['Media'] >= limite_aprovacao else 'Reprovado'

print("\nEstudantes Atualizados:") # Imprimindo todos os estudantes, suas médias e status novamente
for i, aluno in enumerate(alunos, 1):
    print(f'Aluno {i}: {aluno}')

