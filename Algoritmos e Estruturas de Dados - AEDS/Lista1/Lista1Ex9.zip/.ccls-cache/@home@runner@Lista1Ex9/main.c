// Faça um algoritmo que calcule a área de uma circunferência, recebendo o valor do raio // 

#include <stdio.h>
#include <math.h> 

int main(void) {

  float raio , area;

  printf("Digite o valor do raio: \n");
  scanf("%f", &raio);

  area = pow(raio, 2) * 3.14;

  printf("O valor da área é: %.2f \n", area);

  
  return 0;
}