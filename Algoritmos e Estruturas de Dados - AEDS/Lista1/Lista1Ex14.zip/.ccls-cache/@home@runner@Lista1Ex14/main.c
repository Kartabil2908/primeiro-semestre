/* Faça um programa que receba o preço de um produto, calcule e mostre o novo preço em duas condições distintas:
(a) o preço do produto sofreu um desconto de 10%.
(b) o preço do produto sofreu um aumento de 20%. */



#include <stdio.h>

int main(void) {

float produto, desconto, aumento;

  puts("Digite o Valor do produto:");

  scanf("%f", &produto);

desconto = produto - produto*10/100;

aumento = produto + produto*20/100;

printf("O produto após o desconto de 10 por cento é de: %.2f, já o produto com um aumento de 20 por cento é: %.2f", desconto, aumento);
  


  
  return 0;
}