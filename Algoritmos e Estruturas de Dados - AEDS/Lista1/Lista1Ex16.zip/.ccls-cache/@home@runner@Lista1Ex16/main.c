//Faça um algoritmo que receba uma quantidade qualquer em horas e converta em minutos.//


#include <stdio.h>

int main(void) {

float hora, minuto;



    puts("Digite uma quantidade de horas:");
    scanf("%f", &hora);

  
  minuto = hora*60;
  
  printf("A quantidade em minutos será de: %.2f", minuto); 
  
  return 0;
}