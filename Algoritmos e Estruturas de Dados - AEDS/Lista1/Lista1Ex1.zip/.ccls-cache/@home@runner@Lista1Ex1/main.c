// Crie um algoritmo que calcule a soma e o produto de 3 números fornecidos pelo usuário. //

#include <stdio.h>

int main(void) {

  float n1, n2, n3;
  float soma, produto;

printf("qual é o valor do primeiro número?");
scanf("%f", &n1);

  printf("qual é o valor do segundo número?");
scanf("%f", &n2);

  printf("qual é o valor do terceiro número?");
scanf("%f", &n3);

soma = n1+n2+n3;
produto = n1*n2*n3;

  printf("A soma é %f e o produto é %f",soma, produto);

return 0;

}



