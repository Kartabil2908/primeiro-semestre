// Crie um algoritmo que calcule a soma e o produto de 3 números fornecidos pelo usuário. //

#include <stdio.h>

int questao2(void) {

  printf("oieeee");

return 0;
}

