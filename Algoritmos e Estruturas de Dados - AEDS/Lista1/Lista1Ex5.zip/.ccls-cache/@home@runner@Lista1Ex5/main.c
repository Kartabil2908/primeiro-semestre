/*  Faça um algoritmo que receba um número positivo, calcule e mostre:
• o número ao cubo;
• a raiz quadrada do número;
• a raiz cúbica do número;
• o seno do número;
• o cosseno do número.
 -- logarítimo na base 10*/

#include <stdio.h>
#include <math.h>
int main(void) {

float n1;

  printf("Digite um número positivo: \n");
    scanf("%f", &n1);


// o número ao cubo //

  printf("O cubo do número é: %f \n", pow(n1,3));
  
// raiz quadrada do número //

printf("A raiz quadrada do número é: %f \n", sqrt(n1));

  // raiz cúbica do número //
  printf("A raiz cúbica do número é: %f \n", cbrt(n1));


  // seno e cosseno em radianos //
  
printf("O seno do número é: %f \n", sin(n1));

  printf("O cosseno do número é: %f \n", cos(n1));


  // logarítimo na base 10//

  printf("O logarítimo do número na base 10 é: %.2f",log10(n1));
  
  return 0;
}