/*  Um funcionário receberá um aumento de salário. Faça um algoritmo que receba o salário e o percentual de
aumento, calcule e mostre o valor do aumento e o novo salário   */

#include <stdio.h>

int main(void) {

float salario, porcem;

  printf("Digite seu salário \n");
  scanf("%f", &salario);

  printf("Digite o aumento em porcentagem, mas não coloque o símbolo \n");
  scanf("%f", &porcem);

  salario = salario + salario*porcem/100;

printf("O novo salário é de %.2f e o aumento foi de %.2f por cento", salario, porcem);



  
  return 0;
}