/* Sejam P(x1, y1) e Q(x2, y2) dois pontos quaisquer no plano. A distância entre os pontos é dada por
d = √(x2 − x1)2 + (y2 − y1)2.
Faça um algoritmo que leia as coordenadas dos dois pontos, determine e escreva a distância entre eles */


#include <stdio.h>
#include <math.h>
  

int main(void) {


int x1, x2, y1, y2, distancia;

  puts("Qual é a posição do primeiro ponto?");
  scanf("%i %i", &x1 , &y1);

    puts("Qual é a posição do segundo ponto?");
  scanf("%i %i", &y1 , &y2);

  distancia = sqrt((x2-x1)*2 + (y2-y1)*2);

    printf("A distância entre esses dois pontos será de %.2i", distancia);



  
  return 0;
}