// Faça um algoritmo que receba o salário de um funcionário, calcule e mostre o novo salário considerando um aumento de 25% // 

#include <stdio.h>

int main(void) {

 float salario;

  printf("Digite seu salário \n");
  scanf("%f", &salario);

  salario = salario*1.25;

  printf("O novo salário será de %.2f", salario);


  
  return 0;
}