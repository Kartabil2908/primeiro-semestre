/* Implemente um programa que abra o arquivo texto (criado no exercício
anterior) e conte a quantidade de caracteres ‘a’ que estão presentes nele.
Imprima a quantidade na tela */

#include <stdio.h>

int main() {

  FILE *arquivo;
  char string[50];
  int contadorA = 0;
  char caractere;

  arquivo = fopen("arquivoteste.txt", "w"); // abrindo o arquivo //

  scanf("%[^\n]", string); // lendo o que o usuário escreveu //

  fputs(string, arquivo); // gravando no arquivo //

  fclose(arquivo); // fechando o arquivo //

  arquivo = fopen("arquivoteste.txt", "r"); // abrindo o arquivo para leitura //

  // buscando a letra A //

  while ((caractere = fgetc(arquivo)) != EOF) {

    if (caractere == 'a' || caractere == 'A') {
      contadorA++;
    }
  }

  fclose(arquivo); // fechando o arquivo

  printf("O número de A no arquivo é: %d", contadorA);

  return 0;
}