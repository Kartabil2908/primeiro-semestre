// Crie um programa que receba um texto do usuário e grave o texto em um arquivo
// //

#include <stdio.h>

int main() {

  FILE *arquivo;
  char string[50];

  // escaneando a frase //

  printf("Digite sua frase: \n");
  scanf("%[^\n]", string);

  // abrindo o arquivo //

  arquivo = fopen("arquivoexemplo.txt", "w+");

  // gravando a frase no arquivo //

  fputs(string, arquivo);

  // fechando o arquivo //

  fclose(arquivo);

  return 0;
}