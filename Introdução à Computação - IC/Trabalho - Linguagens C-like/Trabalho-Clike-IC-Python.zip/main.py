numero_camisas = 0
contador_p = 0
contador_m = 0

# Lendo o número de camisas, aplicando a condição de existência
while numero_camisas == 0:
    numero_camisas = int(input("Digite o número de camisas entregues:\n"))

tamanho_camisas = []

# Declarando o vetor "tamanho_camisas"
for i in range(numero_camisas):
    tamanho_camisas.append(int(input()))  # Lendo os tamanhos das camisas pedidas

    # Atribuindo a quantidade de cada tipo de camisa pedida
    if tamanho_camisas[i] == 1:
        contador_p += 1
    elif tamanho_camisas[i] == 2:
        contador_m += 1

camisas_p = int(input())  # Verificando as quantidades reais de camisas P
camisas_m = int(input())  # Verificando as quantidades reais de camisas M

# Dando a resposta com a verificação Expectativa x Realidade
if contador_p == camisas_p and contador_m == camisas_m and numero_camisas == camisas_m + camisas_p:
    print("S")
else:
    print("N")


# CURIOSIDADE: muito legal que o código em python ficou minúsculo