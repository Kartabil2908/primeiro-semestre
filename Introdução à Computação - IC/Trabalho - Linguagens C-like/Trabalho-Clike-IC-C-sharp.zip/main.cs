using System;

class Program
{
    static void Main()
    {
        // declarando as variáveis
        int numeroCamisas = 0, contadorP = 0, contadorM = 0, camisasP, camisasM;

        // lendo o número de camisas, aplicando a condição de existência
        do
        {
            Console.WriteLine("Digite o número de camisas entregues:");
            if (!int.TryParse(Console.ReadLine(), out numeroCamisas))
            {
                Console.WriteLine("Por favor, insira um número válido.");
            }
        } while (numeroCamisas == 0);

        int[] tamanhoCamisas = new int[numeroCamisas]; // declarando o vetor "tamanhoCamisas"

        for (int i = 0; i < numeroCamisas; i++)
        {
            if (!int.TryParse(Console.ReadLine(), out tamanhoCamisas[i])) // lendo os tamanhos das camisas pedidas
            {
                Console.WriteLine("Por favor, insira um número válido.");
                i--; // decrementar o índice para repetir a leitura
                continue;
            }

            // atribuindo a quantidade de tipo de camisa pedidas //
            if (tamanhoCamisas[i] == 1)
            {
                contadorP++;
            }

            if (tamanhoCamisas[i] == 2)
            {
                contadorM++;
            }
        }

        if (!int.TryParse(Console.ReadLine(), out camisasP)) // verificando as quantidades reais de camisas P
        {
            Console.WriteLine("Por favor, insira um número válido para camisasP.");
            return;
        }

        if (!int.TryParse(Console.ReadLine(), out camisasM)) // verificando as quantidades reais de camisas M;
        {
            Console.WriteLine("Por favor, insira um número válido para camisasM.");
            return;
        }

        // dando a resposta com a verificação Expectativa x Realidade;
        if (contadorP == camisasP && contadorM == camisasM && numeroCamisas == camisasM + camisasP)
        {
            Console.WriteLine("S");
        }
        else
        {
            Console.WriteLine("N");
        }
    }
}
